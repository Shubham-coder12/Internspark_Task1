# 📁 File Automator — Web Edition

A full-stack file automation system with a cyberpunk web UI, Flask REST API, and Python automation engine.
Now configured with `vercel.json` and a `/tmp` bypass to be deployable on Vercel.
